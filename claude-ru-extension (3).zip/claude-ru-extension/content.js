// Claude.ai → Русский интерфейс (v5 — автообновление с GitHub)

const GITHUB_URL = "https://raw.githubusercontent.com/Rissss256/claude-ru/main/translations.js";
const CHECK_INTERVAL_MS = 60 * 60 * 1000; // проверять раз в час

// Встроенный словарь — работает всегда
const BUILTIN = {
  "New chat": "Новый чат", "New Chat": "Новый чат",
  "Search": "Поиск", "Search chats": "Поиск по чатам",
  "Search chats and projects": "Поиск по чатам и проектам",
  "Customize": "Настроить", "Chats": "Чаты",
  "Projects": "Проекты", "Artifacts": "Артефакты",
  "Claude Code": "Claude Code", "Recents": "Недавние",
  "Recent": "Недавние", "Starred": "Избранное",
  "Today": "Сегодня", "Yesterday": "Вчера",
  "Previous 7 Days": "Последние 7 дней",
  "Previous 30 Days": "Последние 30 дней",
  "Older": "Раньше", "This Week": "На этой неделе",
  "Last Week": "На прошлой неделе", "This Month": "В этом месяце",
  "Toggle sidebar": "Свернуть панель",
  "Free plan": "Бесплатный план", "Pro plan": "Pro план",
  "Reply...": "Написать...", "Reply": "Ответить",
  "How can Claude help you today?": "Чем могу помочь?",
  "Reply to Claude...": "Написать Клоду...",
  "Message Claude...": "Написать Клоду...",
  "Talk with Claude": "Написать Клоду",
  "Add files, connectors, and more": "Добавить файлы, коннекторы и другое",
  "Add files, connectors, and more /": "Добавить файлы, коннекторы и другое",
  "Send": "Отправить", "Send message": "Отправить",
  "Stop": "Остановить", "Retry": "Повторить",
  "Edit": "Редактировать", "Copy": "Копировать",
  "Copied!": "Скопировано!",
  "Good response": "Хороший ответ", "Bad response": "Плохой ответ",
  "Share": "Поделиться", "Upgrade": "Улучшить",
  "Upgrade plan": "Улучшить план", "More options": "Ещё",
  "Share chat": "Поделиться чатом",
  "Only messages up to this point will be shared.": "Будут доступны только сообщения до этой точки.",
  "Keep private": "Оставить приватным",
  "Only you have access": "Доступ только у вас",
  "Create public link": "Создать публичную ссылку",
  "Anyone with the link can view": "Любой с ссылкой сможет просмотреть",
  "Create share link": "Создать ссылку",
  "Copy link": "Скопировать ссылку",
  "Link copied!": "Ссылка скопирована!",
  "Usage Policy": "Политику использования",
  "Delete link": "Удалить ссылку",
  "Your chats with Claude": "Ваши чаты с Клодом",
  "Search your chats...": "Поиск по чатам...",
  "Select": "Выбрать", "No chats yet": "Чатов пока нет",
  "just now": "только что",
  "Search projects...": "Поиск по проектам...",
  "Sort by": "Сортировка:", "Activity": "Активность",
  "Looking to start a project?": "Хотите создать проект?",
  "Upload materials, set custom instructions, and organize conversations in one space.":
    "Загружайте материалы, задавайте инструкции и организуйте беседы в одном месте.",
  "New project": "Новый проект", "Create project": "Создать проект",
  "No projects yet": "Проектов пока нет",
  "Project name": "Название проекта",
  "Project instructions": "Инструкции проекта",
  "Add project instructions": "Добавить инструкции",
  "Add files": "Добавить файлы", "Files": "Файлы",
  "Knowledge": "База знаний", "Members": "Участники",
  "Add members": "Добавить участников",
  "Remove from project": "Удалить из проекта",
  "Move to project": "В проект", "Leave project": "Покинуть проект",
  "Delete project": "Удалить проект", "Edit project": "Редактировать проект",
  "Project settings": "Настройки проекта",
  "Your artifacts": "Ваши артефакты",
  "Search your artifacts...": "Поиск по артефактам...",
  "No artifacts yet": "Артефактов пока нет",
  "All": "Все", "Code": "Код", "Documents": "Документы",
  "Images": "Изображения", "Other": "Другое",
  "Preview": "Предпросмотр", "Run": "Запустить",
  "Download": "Скачать", "Copy code": "Скопировать код",
  "Publish": "Опубликовать", "Published": "Опубликовано",
  "Unpublish": "Снять с публикации",
  "Open in new tab": "Открыть в новой вкладке",
  "Fullscreen": "Полный экран",
  "Edit artifact": "Редактировать артефакт",
  "Delete artifact": "Удалить артефакт",
  "View source": "Посмотреть код",
  "Save to artifacts": "Сохранить в артефакты", "Remix": "Переработать",
  "Customize Claude": "Настроить Клода",
  "Custom instructions": "Пользовательские инструкции",
  "What would you like Claude to know about you?": "Что Клод должен знать о вас?",
  "How would you like Claude to respond?": "Как Клод должен отвечать?",
  "User preferences": "Личные настройки", "Preferences": "Предпочтения",
  "Writing style": "Стиль написания",
  "Concise": "Кратко", "Detailed": "Подробно",
  "Formal": "Формально", "Casual": "Неформально",
  "Enable artifacts": "Включить артефакты",
  "Show side-by-side": "Показывать рядом",
  "characters remaining": "символов осталось",
  "Save preferences": "Сохранить настройки",
  "Reset to defaults": "Сбросить до стандартных",
  "Claude's memory": "Память Клода",
  "Manage memory": "Управление памятью",
  "Clear memory": "Очистить память",
  "No memories yet": "Воспоминаний пока нет",
  "Delete memory": "Удалить воспоминание",
  "Install Claude Code": "Установить Claude Code",
  "Run Claude Code in your terminal": "Запустите Claude Code в терминале",
  "Install": "Установить", "Documentation": "Документация",
  "Copy command": "Скопировать команду",
  "Get started": "Начать", "Learn more": "Подробнее",
  "Rename": "Переименовать", "Delete": "Удалить",
  "Delete chat": "Удалить чат", "Archive": "В архив",
  "Unarchive": "Из архива",
  "Star": "В избранное", "Unstar": "Убрать из избранного",
  "Export chat": "Экспортировать",
  "Profile & Settings": "Профиль и настройки",
  "Settings": "Настройки", "Log out": "Выйти",
  "Sign out": "Выйти", "What's new": "Что нового",
  "Help & support": "Помощь", "Give feedback": "Отзыв",
  "Keyboard shortcuts": "Горячие клавиши",
  "Appearance": "Внешний вид", "Theme": "Тема",
  "Light": "Светлая", "Dark": "Тёмная", "System": "Системная",
  "Notifications": "Уведомления", "Privacy": "Конфиденциальность",
  "Memory": "Память", "Save": "Сохранить",
  "Save changes": "Сохранить", "Cancel": "Отмена",
  "Close": "Закрыть", "Confirm": "Подтвердить",
  "Billing": "Оплата", "Usage": "Использование",
  "Account": "Аккаунт", "Profile": "Профиль",
  "Security": "Безопасность",
  "Connected apps": "Подключённые приложения",
  "Data controls": "Управление данными",
  "Font size": "Размер шрифта",
  "Small": "Маленький", "Medium": "Средний", "Large": "Большой",
  "Extended thinking": "Расширенное мышление",
  "Web search": "Поиск в интернете",
  "Tools": "Инструменты", "Add": "Добавить",
  "Remove": "Удалить", "Add content": "Добавить контент",
  "Attach files": "Прикрепить файлы",
  "Are you sure?": "Вы уверены?",
  "This action cannot be undone.": "Это нельзя отменить.",
  "Delete anyway": "Удалить", "Got it": "Понятно",
  "OK": "ОК", "Yes": "Да", "No": "Нет", "Try again": "Повторить",
  "Show more": "Показать больше", "Show less": "Скрыть",
  "Load more": "Загрузить ещё",
  "Thinking...": "Думаю...", "Loading...": "Загрузка...",
  "Generating...": "Генерирую...",
  "Claude is AI and can make mistakes. Please double-check responses.":
    "Клод — ИИ и может ошибаться. Проверяйте ответы.",
  "Claude can make mistakes. Please double-check responses.":
    "Клод может ошибаться. Проверяйте ответы.",
  "Select all": "Выбрать все", "Deselect all": "Снять все",
  "Delete selected": "Удалить выбранные",
  "Back": "Назад", "Next": "Далее", "Done": "Готово",
  "Apply": "Применить", "Reset": "Сбросить",
  "Error": "Ошибка", "Success": "Успешно",
  "No results found": "Ничего не найдено", "Clear": "Очистить",
  "Name": "Название", "Created": "Создано", "Updated": "Обновлено",
  "Last edited": "Последнее изменение",
};

let T = { ...BUILTIN };

// ── Загрузка словаря из GitHub ────────────────────────────────

async function fetchFromGithub() {
  try {
    const res = await fetch(GITHUB_URL + "?t=" + Date.now(), { cache: "no-store" });
    if (!res.ok) return null;
    const text = await res.text();
    const match = text.match(/const\s+T\s*=\s*(\{[\s\S]*?\});/);
    if (!match) return null;
    const jsonStr = match[1]
      .replace(/\/\/[^\n]*/g, "")
      .replace(/,(\s*[}\]])/g, "$1")
      .replace(/([{,]\s*)([a-zA-Z_$][a-zA-Z0-9_$]*)\s*:/g, '$1"$2":');
    return JSON.parse(jsonStr);
  } catch (e) {
    return null;
  }
}

async function checkAndUpdate() {
  const now = Date.now();
  const stored = await chrome.storage.local.get(["customDict", "lastCheck"]);

  // Применяем сохранённый словарь сразу
  if (stored.customDict) {
    T = { ...BUILTIN, ...stored.customDict };
    fullPass();
  }

  // Проверяем GitHub не чаще раза в час
  if (stored.lastCheck && now - stored.lastCheck < CHECK_INTERVAL_MS) return;

  const fresh = await fetchFromGithub();
  if (!fresh) return;

  await chrome.storage.local.set({
    customDict: fresh,
    lastCheck: now,
    lastUpdate: now,
    dictSize: Object.keys(fresh).length,
  });

  T = { ...BUILTIN, ...fresh };
  fullPass();
}

// Функция для принудительного обновления из popup (кнопка)
window.__claudeRuForceUpdate = async function() {
  const fresh = await fetchFromGithub();
  if (!fresh) return { ok: false, error: "Не удалось загрузить файл с GitHub" };
  await chrome.storage.local.set({
    customDict: fresh,
    lastCheck: Date.now(),
    lastUpdate: Date.now(),
    dictSize: Object.keys(fresh).length,
  });
  T = { ...BUILTIN, ...fresh };
  fullPass();
  return { ok: true, count: Object.keys(fresh).length };
};

// Применить словарь напрямую (из popup без перезагрузки)
window.__claudeRuApplyDict = function(dict) {
  T = { ...BUILTIN, ...dict };
  fullPass();
};

// ── Переводчик ────────────────────────────────────────────────

const ATTRS = ["placeholder", "title", "aria-label", "alt", "data-tooltip"];
const CHAT_SEL = [
  "[data-testid='conversation-turn']",
  "[data-testid='user-message']",
  "[data-testid='assistant-message']",
  ".prose", "pre", "code", "textarea",
];

function inChat(el) {
  let n = el;
  while (n && n !== document.body) {
    if (n.matches) for (const s of CHAT_SEL) {
      try { if (n.matches(s)) return true; } catch (_) {}
    }
    n = n.parentElement;
  }
  return false;
}

function translateEl(el) {
  if (!el || el.nodeType !== Node.ELEMENT_NODE || inChat(el)) return;
  for (const a of ATTRS) {
    const v = el.getAttribute(a);
    if (v && T[v.trim()]) el.setAttribute(a, T[v.trim()]);
  }
  for (const c of el.childNodes) {
    if (c.nodeType !== Node.TEXT_NODE) continue;
    const raw = c.textContent, t = raw.trim();
    if (t && t.length <= 150 && T[t]) c.textContent = raw.replace(t, T[t]);
  }
}

function fullPass() {
  if (!document.body) return;
  for (const el of document.body.querySelectorAll("*")) translateEl(el);
}

// ── MutationObserver ──────────────────────────────────────────

let queue = new Set(), timer = false;
function flush() {
  timer = false;
  queue.forEach(translateEl);
  queue.clear();
}

new MutationObserver(mutations => {
  for (const m of mutations) {
    for (const n of m.addedNodes) {
      if (n.nodeType === Node.ELEMENT_NODE) {
        queue.add(n);
        let i = 0;
        for (const k of n.querySelectorAll("*")) {
          queue.add(k); if (++i >= 40) break;
        }
      }
    }
    if (m.type === "attributes") queue.add(m.target);
  }
  if (!timer) { timer = true; requestIdleCallback(flush, { timeout: 400 }); }
}).observe(document.body, {
  childList: true, subtree: true,
  attributes: true, attributeFilter: ATTRS,
});

// ── SPA-навигация ─────────────────────────────────────────────

let lastUrl = location.href;
function onNavigate() {
  const url = location.href;
  if (url === lastUrl) return;
  lastUrl = url;
  setTimeout(fullPass, 300);
  setTimeout(fullPass, 900);
  setTimeout(fullPass, 2000);
}

const _push = history.pushState.bind(history);
const _replace = history.replaceState.bind(history);
history.pushState    = (...a) => { _push(...a);    onNavigate(); };
history.replaceState = (...a) => { _replace(...a); onNavigate(); };
window.addEventListener("popstate", onNavigate);
new MutationObserver(onNavigate).observe(
  document.querySelector("title") || document.head,
  { childList: true, subtree: true, characterData: true }
);

// ── Старт ─────────────────────────────────────────────────────

fullPass(); // сразу встроенный словарь
checkAndUpdate(); // потом тихо проверяем GitHub
setTimeout(fullPass, 800);
