const GITHUB_URL = "https://raw.githubusercontent.com/Rissss256/claude-ru/main/translations.js";
const $ = id => document.getElementById(id);

// Загружаем статус при открытии попапа
chrome.storage.local.get(["lastUpdate", "dictSize", "lastCheck"], data => {
  if (data.lastUpdate) {
    const d = new Date(data.lastUpdate);
    const mins = Math.round((Date.now() - data.lastUpdate) / 60000);
    const timeStr = mins < 60
      ? `${mins} мин. назад`
      : d.toLocaleDateString("ru") + " " + d.toLocaleTimeString("ru", {hour:"2-digit", minute:"2-digit"});
    $("last-update").textContent = "Обновлено: " + timeStr;
  }
  if (data.dictSize) {
    $("words-count").textContent = data.dictSize + " фраз";
  }
  // Следующая автопроверка
  if (data.lastCheck) {
    const nextMins = Math.max(0, Math.round((data.lastCheck + 3600000 - Date.now()) / 60000));
    $("next-check").textContent = nextMins > 0 ? `Авто-проверка через ${nextMins} мин.` : "Авто-проверка при следующей загрузке";
  }
});

async function doUpdate() {
  const btn = $("updateBtn");
  btn.disabled = true;
  btn.textContent = "⏳ Загружаю...";
  setStatus("loading", "Подключаюсь к GitHub...");

  try {
    // Вызываем функцию в активной вкладке claude.ai
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const claudeTab = tabs.find(t => t.url && t.url.includes("claude.ai"));

    if (!claudeTab) {
      // Нет активной вкладки claude.ai — качаем напрямую из popup
      const res = await fetch(GITHUB_URL + "?t=" + Date.now(), { cache: "no-store" });
      if (!res.ok) throw new Error("HTTP " + res.status + " — файл не найден на GitHub");
      const text = await res.text();
      const match = text.match(/const\s+T\s*=\s*(\{[\s\S]*?\});/);
      if (!match) throw new Error("Неверный формат файла translations.js");
      const jsonStr = match[1]
        .replace(/\/\/[^\n]*/g, "")
        .replace(/,(\s*[}\]])/g, "$1")
        .replace(/([{,]\s*)([a-zA-Z_$][a-zA-Z0-9_$]*)\s*:/g, '$1"$2":');
      const dict = JSON.parse(jsonStr);
      const count = Object.keys(dict).length;
      await chrome.storage.local.set({ customDict: dict, lastUpdate: Date.now(), dictSize: count, lastCheck: Date.now() });
      setStatus("ok", `✓ Загружено ${count} фраз. Обновите вкладку claude.ai.`);
      $("words-count").textContent = count + " фраз";
      $("last-update").textContent = "Обновлено: только что";
      return;
    }

    // Есть вкладка — вызываем напрямую
    const results = await chrome.scripting.executeScript({
      target: { tabId: claudeTab.id },
      func: () => window.__claudeRuForceUpdate ? window.__claudeRuForceUpdate() : null,
    });

    const result = results?.[0]?.result;
    if (!result) throw new Error("Расширение не загружено на вкладке. Обновите страницу.");
    if (!result.ok) throw new Error(result.error || "Неизвестная ошибка");

    setStatus("ok", `✓ Применено ${result.count} фраз`);
    $("words-count").textContent = result.count + " фраз";
    $("last-update").textContent = "Обновлено: только что";
    $("next-check").textContent = "Авто-проверка через 60 мин.";

  } catch (e) {
    setStatus("error", "✗ " + e.message);
  } finally {
    btn.disabled = false;
    btn.textContent = "🔄 Обновить сейчас";
  }
}

function setStatus(type, text) {
  const dot = $("dot");
  const log = $("log");
  dot.className = "dot" + (type === "loading" ? " loading" : type === "error" ? " error" : "");
  log.className = "log" + (type === "ok" ? " ok" : type === "error" ? " err" : "");
  log.textContent = text;
}

$("updateBtn").addEventListener("click", doUpdate);
